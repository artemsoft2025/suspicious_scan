@echo off
cd /d "%~dp0"
suspicious_scan.exe C:\ --autostart --registry --procmon
pause