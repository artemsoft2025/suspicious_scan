@echo off
cd /d "%~dp0"
suspicious_scan.exe C:\ D:\ E:\
pause